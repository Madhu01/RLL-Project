package in.companyEmployee.travel.util;
import org.springframework.stereotype.Component;
import in.companyEmployee.travel.model.*;



@Component
public class RegisterUtil {

	public void mapToActualObject(Register actual, Register register) {
	
		actual.setEmpid(register.getEmpid());
		actual.setName(register.getName());
		actual.setDepartment(register.getDepartment());
		actual.setAddress(register.getAddress());
		actual.setPassword(register.getPassword());
		actual.setPhoneno(register.getPhoneno());
		
	}

}
