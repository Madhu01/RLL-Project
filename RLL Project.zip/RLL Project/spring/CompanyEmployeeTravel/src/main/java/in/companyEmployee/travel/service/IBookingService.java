package in.companyEmployee.travel.service;
import java.util.List;
import java.util.Optional;

import  in.companyEmployee.travel.model.*;


public interface IBookingService {
	Integer saveBooking(Booking s);
	
	void deleteBooking(Integer empid);

	List<Booking> getAllBooking();
	Optional<Booking> getOneBooking(Integer empid);

	boolean isBookingExist(Integer id);
}
