package in.companyEmployee.travel.service;
import java.util.List;
import java.util.Optional;

import  in.companyEmployee.travel.model.*;

public interface IFeedbackService {


	Integer saveFeedback(Feedback s);
	List<Feedback> getAllFeedback();

	
}
