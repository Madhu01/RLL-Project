package in.companyEmployee.travel.util;
import org.springframework.stereotype.Component;
import in.companyEmployee.travel.model.*;



@Component
public class BookingUtil {

	public void mapToActualObject(Booking actual, Booking travel) {
		
		actual.setEmpid(travel.getEmpid());
		actual.setVehicle(travel.getVehicle());
		actual.setPeople(travel.getPeople());
		actual.setTime1(travel.getTime1());
		actual.setDate1(travel.getDate1());
		actual.setDfrom(travel.getDfrom());
		actual.setDto(travel.getDto());
		actual.setDetails(travel.getDetails());
	}

}
