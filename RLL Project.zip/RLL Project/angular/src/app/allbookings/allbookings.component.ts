import { Component, OnInit } from '@angular/core';
import {BookingService} from '../booking.service';
import { Booking } from './../booking';
import { Router } from '@angular/router';
@Component({
  selector: 'app-bookingall',
  templateUrl: './allbookings.component.html',
  styleUrls: ['./allbookings.component.css']
})
export class AllbookingsComponent implements OnInit {
    bookings:Booking[];
    empid:number;
    message: string;
  constructor(private service: BookingService, private router: Router) { }

  ngOnInit(): void {
  
  this.getAllBookings();
}
    getAllBookings() {
    return this.service.getAllBookings()
    .subscribe(
      data => {
        this.bookings = data;
      }, error => {
        console.log(error);
      }
    );
  }
  deletebooking(empid: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneBooking(empid).subscribe(data => {
        this.message = data;
        this.getAllBookings();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }
  logout()
  {
    this.router.navigate(['/adminlogin']);
  }

  allFeedback()
  {
    this.router.navigate(['/allfeedback']);
  }
  allbookings()
  {
    this.router.navigate(['/allbookings']);
  }
  allEmployees()
  {
    this.router.navigate(['/allemployees']);
  }

}