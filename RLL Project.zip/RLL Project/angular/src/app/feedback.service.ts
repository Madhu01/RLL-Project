import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback} from './feedback';


@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  private basePath = 'http://localhost:9040/rest/feedback';

  constructor(private http: HttpClient) { }


  getAllFeedback(): Observable<Feedback[]> {
    return this.http.get<Feedback[]>(`${this.basePath}/feedbackD`);
  }
  createFeedback(feedback: Feedback): Observable<any> {
    return this.http.post(`${this.basePath}/feedbacksave`, feedback, {responseType: 'text'});
  }

}