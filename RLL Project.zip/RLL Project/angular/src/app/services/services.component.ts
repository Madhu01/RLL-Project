import { Component, OnInit } from '@angular/core';
import { BookingService } from './../booking.service';
import { Booking } from '../booking';
import { Router } from '@angular/router';


@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  // form backing object
  booking: Booking;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: BookingService,private router: Router) { }
 
  ngOnInit(): void {
    // when page is loaded clear form data
    this.booking = new Booking();
  }

  // tslint:disable-next-line: typedef
  createBook() {
    if ((this.booking.empid==null )||(this.booking.date1==null )|| (this.booking.details==null )||(this.booking.dfrom==null )||(this.booking.dto==null )|| (this.booking.people==null )||(this.booking.time1==null )|| (this.booking.vehicle==null )){
      alert("enter data in all required(*) feilds");
    }
    else{
    this.service.createBooking(this.booking)
    .subscribe(data => {
      this.message = data; // read message
      
      this.booking = new Booking(); // clear form
    }, error => {
      console.log(error);
    });
  }}
  allBookings(){
    this.router.navigate(['/onebooking']);
  }
  logout(){
    this.router.navigate(['/login']);
  }
}