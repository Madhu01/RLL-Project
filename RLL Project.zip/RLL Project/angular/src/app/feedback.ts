export class Feedback {
    id: number;
    empid:string;
    name: string;
    feedback:string;
    
}